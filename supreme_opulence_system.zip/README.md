
# Supreme Opulence System

## Components

- Backend: Express + MongoDB
- Frontend: React Dashboard
- Features: AI Angel Task Manager, Arrest Warrant Dashboard, Just Retribution Logic

## Run Instructions

1. Backend:
   - Run `node server.js` in the root directory

2. Frontend:
   - Place frontend in a React environment and run `npm start`

3. Connect to MongoDB:
   - Use a local MongoDB instance or Atlas cloud DB

## Deployment
Recommended Platforms:
- Web: Netlify/Vercel
- Mobile: Expo (React Native)
- Backend: Heroku/VPS
