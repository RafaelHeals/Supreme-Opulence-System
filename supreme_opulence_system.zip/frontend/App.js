
import React, { useEffect, useState } from 'react';
import axios from 'axios';

function App() {
  const [tasks, setTasks] = useState([]);
  const [form, setForm] = useState({ angelName: '', jurisdiction: '', task: '', status: 'pending' });

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    const res = await axios.get('http://localhost:4000/tasks');
    setTasks(res.data);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post('http://localhost:4000/tasks', {
      ...form,
      timestamp: new Date()
    });
    fetchTasks();
    setForm({ angelName: '', jurisdiction: '', task: '', status: 'pending' });
  };

  return (
    <div>
      <h1>Supreme Opulence System Dashboard</h1>
      <form onSubmit={handleSubmit}>
        <input value={form.angelName} onChange={e => setForm({ ...form, angelName: e.target.value })} placeholder="Angel Name" />
        <input value={form.jurisdiction} onChange={e => setForm({ ...form, jurisdiction: e.target.value })} placeholder="Jurisdiction" />
        <input value={form.task} onChange={e => setForm({ ...form, task: e.target.value })} placeholder="Task Description" />
        <button type="submit">Assign Task</button>
      </form>

      <ul>
        {tasks.map((task, index) => (
          <li key={index}>{task.angelName} in {task.jurisdiction}: {task.task} – {task.status}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;
